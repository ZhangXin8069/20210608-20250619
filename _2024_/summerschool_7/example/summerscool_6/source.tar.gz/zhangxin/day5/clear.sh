
rm -rf dummy_run* XMLLOG
rm -rf  hmc_*.err hmc_*.out mlog mout
