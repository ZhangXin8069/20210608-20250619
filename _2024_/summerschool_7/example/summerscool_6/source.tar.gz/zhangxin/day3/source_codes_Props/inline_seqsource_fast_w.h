// -*- C++ -*-
/*! \file
 * \brief Inline construction of sequential sources
 *
 * Sequential source construction
 */

#ifndef __inline_seqsource_fast_w_h__
#define __inline_seqsource_fast_w_h__

#include "chromabase.h"
#include "meas/inline/abs_inline_measurement.h"
#include "io/qprop_io.h"

namespace Chroma 
{ 
  /*! \ingroup inlinehadron */
  namespace InlineSeqSourceFastEnv 
  {
    extern const std::string name;
    bool registerAll();


    //! Parameter structure
    /*! \ingroup inlinehadron */
    struct Params 
    {
      Params();
      Params(XMLReader& xml_in, const std::string& path);
      void writeXML(XMLWriter& xml_out, const std::string& path);

      unsigned long      frequency;

      // True if sink-smeared props are given; default=false
      bool               smeared_props;
      multi1d<int>       multi_tSinks;

      SeqSource_t        param;
      PropSinkSmear_t    sink_header;

      struct NamedObject_t
      {
        std::string            gauge_id;
        multi1d<std::string>   prop_ids;
        multi1d<std::string>   seqsource_id;
      } named_obj;
    };

    //! Compute a sequential source
    /*! \ingroup inlinehadron */
    class InlineMeas : public AbsInlineMeasurement 
    {
      public:
        ~InlineMeas() {}
        InlineMeas(const Params& p) : params(p) {}
        InlineMeas(const InlineMeas& p) : params(p.params) {}

        unsigned long getFrequency(void) const {return params.frequency;}

        //! Do the measurement
        void operator()(const unsigned long update_no,
            XMLWriter& xml_out); 

      private:
        Params params;
    };

  }

}

#endif
