// -*- C++ -*-
/*! \file
 * \brief Inline measurement of qpropadd
 *
 * Form-factors
 */

#ifndef __inline_qpropadd_Cohen_w_h__
#define __inline_qpropadd_Cohen_w_h__

#include "chromabase.h"
#include "meas/inline/abs_inline_measurement.h"

namespace Chroma 
{ 
  /*! \ingroup inlinehadron */
  namespace InlineQpropAddCohenEnv 
  {
    extern const std::string name;
    bool registerAll();

    //! Parameter structure
    /*! \ingroup inlinehadron */
    struct Params 
    {
      Params();
      Params(XMLReader& xml_in, const std::string& path);
      void writeXML(XMLWriter& xml_out, const std::string& path);

      unsigned long      frequency;

      struct NamedObject_t
      {
        int              j_decay;
        multi1d<int>     tA;
        multi1d<int>     tB;
	Real             factorA;
	std::string      propA;    
	Real             factorB;
	std::string      propB;   
	std::string      propApB; 
      } named_obj;
    };


    //! Inline measurement of to add two props
    /*! \ingroup inlinehadron */
    class InlineMeas : public AbsInlineMeasurement 
    {
    public:
      ~InlineMeas() {}
      InlineMeas(const Params& p) : params(p) {}
      InlineMeas(const InlineMeas& p) : params(p.params) {}

      unsigned long getFrequency(void) const {return params.frequency;}

      //! Do the measurement
      void operator()(const unsigned long update_no,
		      XMLWriter& xml_out); 

    private:
      Params params;
    };

  }

}

#endif
