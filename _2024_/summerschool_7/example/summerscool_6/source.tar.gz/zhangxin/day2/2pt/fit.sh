python ./c2pt_read.py 
python c2pt_meff.py 
python ./zfit.py

