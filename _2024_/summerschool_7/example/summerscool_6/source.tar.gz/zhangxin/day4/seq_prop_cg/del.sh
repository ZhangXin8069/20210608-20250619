rm -rf Jobs ini_out_file  log_file *.err *.out
